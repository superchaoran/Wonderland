<?php session_start();?>
<!doctype html>
<html lang="en-US">
<head>
  <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
  <title>welcome to wonderland</title>
  <link rel="shortcut icon" href="http://designshack.net/favicon.ico">
  <link rel="icon" href="http://designshack.net/favicon.ico">
  <link rel="stylesheet" type="text/css" media="all" href="style.css">
  <!--<link href="bootstrap/css/bootstrap.css" rel="stylesheet">
  <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="bootstrap/css/bootstrap-responsive.css" rel="stylesheet">
  <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">-->
  <script type="text/javascript" src="/js/jquery-1.9.1.min.js"></script>
  <script type="text/javascript" charset="utf-8" src="/js/jquery.leanModal.min.js"></script>
  <!-- jQuery plugin leanModal under MIT License http://leanmodal.finelysliced.com.au/ -->
</head>

<body>
  <div id="topbar"><a href="http://www.facebook.com">like us on facebook</a></div>
  <div id="w">
    <div class="content" style="text-decoration: none;">
     <h1><a href="http://wonderland.web.engr.illinois.edu" style="color: #000000;text-decoration: none;">Welcome to the wonderland</a></h1>
      
        <?php include  $_SERVER['DOCUMENT_ROOT'] . "/core/login_bar.php"; ?>
      
    </div>  
      <!--<button type="button" class="btn btn-default btn-lg">Large button</button>
      <button type="button" class="btn btn-default btn-lg">Large button</button>-->
    <div class="content">  
      <div id="display"></div>
      <a href="/search/searchBackend.php" class="large_btn" id = "view"> View Lease</a>
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <a href="form.php" class="large_btn" id = "post"> Post Lease</a>
    </div>
  </div>



 <?php include $_SERVER['DOCUMENT_ROOT'] . "/core/loginModel.php"; ?>
<script type="text/javascript">


$(function(){
  /*
  $('#loginform').submit(function(e){
    var postData = $(this).serializeArray();
    $.post("/core/login.php",function(data) {
        $('#display').html(data);
    }
    );
    return false;
  });*/

/*
$("#loginform").submit(function(e)
    {
        var postData = $(this).serializeArray();
        //alert(postData);
        var formURL = $(this).attr("action");
        $.ajax(
        {
            url:formURL,
            type:"POST",
            data:postData,
            success:function(data, textStatus, jqXHR) 
            {
                //data: return data from server
                //alert(data);
                //$("#display").html(data);
                //$("#commentFormReturn").html(data);
                //alert(data);
                //window.location= '/core/loginWait.php';
            },
            error: function(jqXHR, textStatus, errorThrown) 
            {
                //if fails      
            }
        });
        e.preventDefault(); //STOP default action
    });


  $('#singupform').submit(function(e){
    return false;
  });*/
  
  $('#modaltrigger1').leanModal({ top: 110, overlay: 0.45, closeButton: ".hidemodal" });
  $('#modaltrigger2').leanModal({ top: 110, overlay: 0.45, closeButton: ".hidemodal" });
  //$('#modaltrigger3').leanModal({ top: 110, overlay: 0.45, closeButton: ".hidemodal" });
  //$('#modaltrigger3').click();
});
</script>
</body>
</html>