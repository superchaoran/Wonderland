<?php session_start();?>
<!doctype html>
<html lang="en-US">
<head>
  <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
  <title>welcome to wonderland</title>
  <link rel="shortcut icon" href="http://designshack.net/favicon.ico">
  <link rel="icon" href="http://designshack.net/favicon.ico">
  <link rel="stylesheet" type="text/css" media="all" href="/style.css">
  <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
  <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="bootstrap/css/bootstrap-responsive.css" rel="stylesheet">
  <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
  <script type="text/javascript" src="/js/jquery-1.9.1.min.js"></script>
  
  <script type="text/javascript" charset="utf-8" src="/js/jquery.leanModal.min.js"></script>
  <!-- jQuery plugin leanModal under MIT License http://leanmodal.finelysliced.com.au/ -->


  <?php include $_SERVER['DOCUMENT_ROOT'] . "/core/loginModel.php"; ?>
  <script type="text/javascript">
    $(function(){
      $('#modaltrigger1').leanModal({ top: 110, overlay: 0.45, closeButton: ".hidemodal" });
      $('#modaltrigger2').leanModal({ top: 110, overlay: 0.45, closeButton: ".hidemodal" });
    });
  </script>
</script>


</head>

<body>
  <div id="topbar"><a href="http://www.facebook.com">like us on facebook</a></div>
  <div id="w">
    <div class="content">
      <h1><a href="http://wonderland.web.engr.illinois.edu" style="color: #000000;text-decoration: none;">Welcome to the wonderland</a></h1>
        <?php include  $_SERVER['DOCUMENT_ROOT'] . "/core/login_bar.php"; ?>
         <p><br></p><p></p><p></p><p></p><p></p><p></p>
        <?php include $_SERVER['DOCUMENT_ROOT'] . '/search/searchEngine.php';?>
<p><br></p><p></p><p></p><p></p><p></p><p></p>
<?php include_once $_SERVER['DOCUMENT_ROOT'] .
    '/includes/helpers.inc.php'; ?>

<?php if (is_array($posts)): ?>
    <?php foreach ($posts as $post):?>
    <?php if($post['parentPostID']==0): ?>

    <?php if(isset($_SESSION['email'])): //$_SESSION['email']!==""?>
    <div style="float:left">
      <form action="/addForm.php" method="post">
        <div>
          <input type="hidden" name="id" value="<?php
              htmlout($post['postID']); ?>">
          <input type="submit" name="action" value="Delete">
        </div>
      </form>    
    </div>
  <?php endif;?>

      <blockquote>
        <p style= "text-align:left">
          <?php echo "<strong>Rent:</strong>$".$post['pricePerMonth']." <strong>noOfBedrooms:</strong>".$post['noOfBedrooms']." <strong>Provider:</strong>".$post['provider']." <strong>Address:</strong>".$post['address']; ?> &nbsp;&nbsp;
          <?php if(isset($_SESSION['email'])): //$_SESSION['email']!==""?>
            <a href="/displaypost.php?id=<?=$post['postID'] ?>" class="button button-small">Learn More</a></br>
          <?php endif;?>
          </br>
        </p>
      </blockquote>
    <?php endif;?>
    <?php endforeach; ?>
<?php endif;?>

<?php if (!is_array($posts)): ?>
  <?php echo "<p style=:\"font-size:24px;\"><strong>No Results Match!</strong><p>"; ?>
<?php endif;?>




    </div>
  </div>


</body>
</html>
