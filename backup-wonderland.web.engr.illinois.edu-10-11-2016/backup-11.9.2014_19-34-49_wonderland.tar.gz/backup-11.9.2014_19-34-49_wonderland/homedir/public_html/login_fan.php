<?php
include 'includes/db.inc.php';
	//database connection
//define ()
echo "abc";
?>