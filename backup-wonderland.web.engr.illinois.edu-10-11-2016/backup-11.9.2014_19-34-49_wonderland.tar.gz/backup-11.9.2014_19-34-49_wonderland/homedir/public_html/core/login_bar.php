
<?php

if(isset($_SESSION['email'])){
	echo "<p style=\"font-size: 20px;\">Logged in as ".$_SESSION['email']."&nbsp&nbsp";
	echo "<a href=\"\core\logoutWait.php\">Log Out</a></p>";

}
else{
	echo "<left><a href=\"#loginmodal1\" class=\"flatbtn\" id=\"modaltrigger1\">Member   Login</a></left>";
	echo "<left><a href=\"#loginmodal2\" class=\"flatbtn\" id=\"modaltrigger2\">Create account</a></left>";
}
?>