<?php

//session_start();
error_reporting(0);

include 'includes/db.inc.php';
$errors = array();

?>