<?php session_start();?>
<!doctype html>
<html lang="en-US">
<head>
  <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
  <title>welcome to wonderland</title>
  <link rel="shortcut icon" href="http://designshack.net/favicon.ico">
  <link rel="icon" href="http://designshack.net/favicon.ico">
  <link rel="stylesheet" type="text/css" media="all" href="style.css">
  <!--<link href="bootstrap/css/bootstrap.css" rel="stylesheet">
  <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="bootstrap/css/bootstrap-responsive.css" rel="stylesheet">
  <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">-->
  <script type="text/javascript" src="/js/jquery-1.9.1.min.js"></script>
  <script type="text/javascript" charset="utf-8" src="/js/jquery.leanModal.min.js"></script>
  <!-- jQuery plugin leanModal under MIT License http://leanmodal.finelysliced.com.au/ -->



  <?php include $_SERVER['DOCUMENT_ROOT'] . "/core/loginModel.php"; ?>
	<script type="text/javascript">
		$(function(){
		  $('#modaltrigger1').leanModal({ top: 110, overlay: 0.45, closeButton: ".hidemodal" });
		  $('#modaltrigger2').leanModal({ top: 110, overlay: 0.45, closeButton: ".hidemodal" });
		});
 	</script>
</head>

<body>
  <div id="topbar"><a href="http://www.facebook.com">like us on facebook</a></div>
  <div id="w">
    <div class="content">
      <h1><a href="http://wonderland.web.engr.illinois.edu" style="color: #000000;text-decoration: none;">Welcome to the wonderland</a></h1>
  <?php include  $_SERVER['DOCUMENT_ROOT'] . "/core/login_bar.php"; ?>
    </div>  
      <!--<button type="button" class="btn btn-default btn-lg">Large button</button>
      <button type="button" class="btn btn-default btn-lg">Large button</button>-->
    <div class="content"> 




	<div style="float: left; margin-right:20px;">
	
		<!--<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"> -->
		<form method="post" name="commentForm" id="commentForm" action="addForm.php">

			<div style="float: left; margin-right:20px;">

			<div>
			Title:<br><input type="text" name="postTitle" size="41" value="">
			<br><br>
			</div>

			<div>
			startDate:<br><input type="date" name="startDate" rows="20" cols="30">
			<br><br>
			</div>

			<div>
			endDate:<br><input type="date" name="endDate" rows="20" cols="30">
			<br><br>
			</div>

			<div>
			pricePerMonth(between 50 and 5000):<br><input type="number" name="pricePerMonth" min="50" max="5000">
			<br><br>
			</div>

			<div>
			noOfBedrooms(between 1 and 8):<br><input type="number" name="noOfBedrooms" min="1" max="8">
			<br><br>
			</div>

			<div>
			address:<br><input type="text" name="address" size="41" value="">
			<br><br>
			</div>

			<div>
			provider:(CPM, University Group, JSM or Personal)<br><input type="text" name="provider" size="41" value="">
			<br><br>
			</div>

			</div>

			<div style="float: left;">
			Content:<br><textarea name="postContent" rows="30" cols="50"></textarea>
		 	</div>
		 	<br><br>


			<input type="submit" name="submit" value="Submit"> 
		</form>
		<div id="commentFormReturn"></div>
	</div>
<p></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></p>

	<!--
</body>-->







</div>
  </div>
  


</body>
</html>
