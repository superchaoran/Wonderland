<?php
include_once $_SERVER['DOCUMENT_ROOT'] . '/includes/magicquotes.inc.php';
include $_SERVER['DOCUMENT_ROOT'] . '/includes/db.inc.php';




$minPrice="1";$maxPrice="10000";$noOfBedrooms="any";
$searchString="";
//search realEstate.address,post.postTitle,post.postContent


//$noOfBedrooms=$_POST['noOfBedrooms'];
if (isset($_POST['minPrice']))
   if ($_POST['minPrice'] !== '')
      $minPrice=$_POST['minPrice'];
if (isset($_POST['maxPrice']))
   if ($_POST['maxPrice'] !== '')
      $maxPrice=$_POST['maxPrice'];
if (isset($_POST['noOfBedrooms']))
   if ($_POST['noOfBedrooms'] !== '' )
      $noOfBedrooms=$_POST['noOfBedrooms'];
if (isset($_POST['searchString']))
   if ($_POST['searchString'] !== '' )
      $searchString=$_POST['searchString'];


try
{
	$sql ="";
	if($noOfBedrooms==="any"){
		$sql='SELECT postID,postTitle,postContent,startDate,endDate,pricePerMonth,
		              noOfBedrooms,address,post.createdDate,provider
		      FROM post INNER JOIN realEstate 
		      ON post.postID=realEstate.realEstateID
		      WHERE realEstate.pricePerMonth>='.$minPrice.' AND realEstate.pricePerMonth<='.$maxPrice.
		      ' AND (realEstate.address LIKE \'%'.$searchString.'%\''.
				' OR realEstate.provider LIKE \'%'.$searchString.'%\''
				.')';
	}
	else if($noOfBedrooms==="6"){
		$sql='SELECT postID,postTitle,postContent,startDate,endDate,pricePerMonth,
		              noOfBedrooms,address,post.createdDate,provider
		      FROM post INNER JOIN realEstate 
		      ON post.postID=realEstate.realEstateID
		      WHERE realEstate.pricePerMonth>='.$minPrice.' AND realEstate.pricePerMonth<='.$maxPrice.' AND realEstate.noOfBedrooms>=6'.
		      ' AND (realEstate.address LIKE \'%'.$searchString.'%\''.
				' OR realEstate.provider LIKE \'%'.$searchString.'%\''
				.')';
	}
	else{
		$sql='SELECT postID,postTitle,postContent,startDate,endDate,pricePerMonth,
		              noOfBedrooms,address,post.createdDate,provider
		      FROM post INNER JOIN realEstate 
		      ON post.postID=realEstate.realEstateID
		      WHERE realEstate.pricePerMonth>='.$minPrice.' AND realEstate.pricePerMonth<='.$maxPrice.' AND realEstate.noOfBedrooms='.$noOfBedrooms.
		      ' AND (realEstate.address LIKE \'%'.$searchString.'%\''.
				' OR realEstate.provider LIKE \'%'.$searchString.'%\''
				.')';
	}
  $result = $pdo->query($sql);

}
catch (PDOException $e)
{
  $error = 'Error fetching jokes: ' . $e->getMessage();
  include 'error.html.php';
  exit();
}

foreach ($result as $row)
{

$posts[] = array(
    'postID' => $row['postID'],
    'postTitle' => $row['postTitle'],
    'postContent' => $row['postContent'],
    'startDate' => $row['startDate'],
    'endDate'=> $row['endDate'],
    'pricePerMonth' => $row['pricePerMonth'],
    'noOfBedrooms' => $row['noOfBedrooms'],
    'address' => $row['address'],
    'createdDate' => $row['createdDate'],
    'provider' => $row['provider']);
  //echo $row['postID']."</br>".$row['postTitle']."</br>".$row['postContent'];
}
include 'displaySearch.php';