    <div style="float: left;background=#fff;margin-left:2px">
  
    <!--<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"> -->

    <form method="post" name="commentForm" id="commentForm" action="/search/searchBackend.php" style="font-size:15px;">

      search:<input type="text" style="font-size:15px;" name="searchString" size="30" placeholder="search:address,provider"
      <?php echo "value=\"".$searchString."\">";?>
      min rent<input type="text" name="minPrice" style="font-size:15px;" size="10" placeholder="min"
      <?php echo "value=\"".$minPrice."\">";?>
      max rent<input type="text" name="maxPrice" style="font-size:15px;" size="10" placeholder="max"
      <?php echo "value=\"".$maxPrice."\">";?>
      Bedrooms<select style="font-size:15px;" name="noOfBedrooms" >
      <option value="any" selected="selected">any</option>
      <option value="1">1BR</option>
      <option value="2">2BR</option>
      <option value="3">3BR</option>
      <option value="4">4BR</option>
      <option value="5">5BR</option>
      <option value="6">6BR+</option>
      </select>
      <input id="searchbtn" type="submit" value="search">
    </form>
  </div>