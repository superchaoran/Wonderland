-- MySQL dump 10.13  Distrib 5.1.73, for unknown-linux-gnu (x86_64)
--
-- Host: engr-cpanel-mysql.engr.illinois.edu    Database: wonderland_wonderland
-- ------------------------------------------------------
-- Server version	5.1.73

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `categoryID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`categoryID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` (`categoryID`, `name`) VALUES (1,'sublease');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post`
--

DROP TABLE IF EXISTS `post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post` (
  `postID` int(11) NOT NULL AUTO_INCREMENT,
  `postTitle` text,
  `postContent` text,
  `userID` int(11) DEFAULT NULL,
  `parentPostID` int(11) DEFAULT NULL,
  `realEstateID` int(11) DEFAULT NULL,
  `createdDate` date NOT NULL,
  PRIMARY KEY (`postID`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post`
--

LOCK TABLES `post` WRITE;
/*!40000 ALTER TABLE `post` DISABLE KEYS */;
INSERT INTO `post` (`postID`, `postTitle`, `postContent`, `userID`, `parentPostID`, `realEstateID`, `createdDate`) VALUES (12,NULL,'Come ride with me,',NULL,2,NULL,'2013-12-11'),(13,NULL,'Through the veins of history.',NULL,2,NULL,'2013-12-11'),(14,NULL,'I\'ll show you how God',NULL,2,NULL,'2013-12-11'),(15,NULL,'Falls asleep on his job.',NULL,2,NULL,'2013-12-11'),(16,NULL,'How can we win,',NULL,2,NULL,'2013-12-11'),(17,NULL,'When fools can be kings?',NULL,2,NULL,'2013-12-11'),(18,NULL,'Don\'t waste your time',NULL,2,NULL,'2013-12-11'),(19,NULL,'Or time will waste you.',NULL,2,NULL,'2013-12-11'),(21,NULL,'One Friday night I took a pill or maybe two,',NULL,3,NULL,'2013-12-11'),(22,NULL,'Down at the car park I saw everyone I knew.',NULL,3,NULL,'2013-12-11'),(23,NULL,'And before the night had started,',NULL,3,NULL,'2013-12-11'),(24,NULL,'We had planned to crush a party.',NULL,3,NULL,'2013-12-11'),(25,NULL,'Just a place that someone knew,',NULL,3,NULL,'2013-12-11'),(26,NULL,'A local house belonging to a ganster crew.',NULL,3,NULL,'2013-12-11'),(27,NULL,'It ain\'t no use to sit and wonder why, babe',NULL,4,NULL,'2013-12-11'),(28,NULL,'If you don’t know by now.',NULL,4,NULL,'2013-12-11'),(30,NULL,'An\' it ain\'t no use to sit and wonder why, babe',NULL,4,NULL,'2013-12-11'),(32,NULL,'It will never do somehow',NULL,4,NULL,'2013-12-11'),(33,NULL,'So go ahead and ask her',NULL,8,NULL,'2013-12-11'),(34,NULL,'For happy ever after',NULL,8,NULL,'2013-12-11'),(35,NULL,'‘Cause nobody knows what’s coming',NULL,8,NULL,'2013-12-11'),(36,NULL,'So why not take a chance on loving',NULL,8,NULL,'2013-12-11'),(37,NULL,'When your rooster crows at the break of dawn',NULL,29,NULL,'2013-12-11'),(38,NULL,'Look out your window and I\'ll be gone',NULL,29,NULL,'2013-12-11'),(39,NULL,'You\'re the reason I\'m travlin\' on',NULL,29,NULL,'2013-12-11'),(41,NULL,'Don\'t think twice, it\'s all right',NULL,31,NULL,'2013-12-11'),(42,NULL,'Well, it ain\'t no use in turnin\' on your light, babe',NULL,31,NULL,'2013-12-11'),(43,NULL,'Come on, pour the glass and tempt me',NULL,40,NULL,'2013-12-11'),(44,NULL,'Either half-full or half-empty',NULL,40,NULL,'2013-12-11'),(45,NULL,'‘Cause if it all comes down to flavor',NULL,40,NULL,'2013-12-11'),(47,NULL,'I will leave behind all of my clothes ',NULL,46,NULL,'2013-12-11'),(48,NULL,'I wore when I was with you, ',NULL,46,NULL,'2013-12-11'),(49,NULL,'wonderful',NULL,3,NULL,'2013-12-11'),(50,'wonderful house','GREAT',NULL,NULL,NULL,'2013-12-11'),(51,NULL,'WONDERFUL',NULL,50,NULL,'2013-12-11'),(52,NULL,'great',NULL,50,NULL,'2013-12-11'),(53,NULL,'aaaaaaaaaaa',NULL,50,NULL,'2013-12-11'),(54,'Upgraded Apts at Nantucket Cove Come See!! (Champaign,IL)','Redefining Excellence In Apartment Living...\r\n\r\n\r\n\r\nNantucket Cove is a premier upscale luxury rental community...Where prestige and elegance have reached new heights. Nantucket Cove offers a timeless and unforgettable lifestyle as harmony, comfort, and tranquility flow through the architecture of every apartment home. Our world class amenities most certainly set us apart from the rest! Just a short walk to fine dining, exclusive shopping and entertainment. We love your pets as much as you do, as we offer a private pet park. Nantucket Cove is where style and sophistication come together to create a new way of living. Reserve your new home at Nantucket Cove Today! www.mckinley.com Apply Online today!\r\n\r\n\r\n\r\n\r\n\r\n\r\nLuxury Community Features:\r\n\r\n2, 3, & 4 Luxury Apartment Homes \r\n24-Hour Emergency Service \r\nAsk about Our Preferred Employer Program \r\nExclusive Clubhouse \r\nGated Community \r\nGarages \r\nResort Style Swimming Pool & Sundeck \r\nBusiness Center \r\nConference Rooms \r\nWasher and Dryers Included \r\nHigh Speed Internet \r\nGet Fit Fitness Center \r\nIndoor Basketball Court \r\nSand Volleyball \r\nBilliards Room \r\nArcade Room \r\nBBQ and Picnic Area \r\nBike Racks \r\nBark Park \r\nCar Wash \r\nPet Friendly \r\nEasy Access to Public Transportation \r\nWalking Distance to Shopping And Dining \r\nFriendly Professional Management Team \r\nWheelchair Access \r\nSecurity Deposit: $150-$300, Hold Fee: $100, Application Fee: $35 per person, Pet Fee: $200, Pet Rent: $20 *Aggressive Breed Restrictions and 2 pet max. \r\n\r\nContact Drew at the Leasing Office to hear about our great specials!! \r\n\r\nThe Perfect Blend of Luxury and Convenience',NULL,NULL,NULL,'2013-12-11'),(55,'Nantucket Cove Pre-Leasing! (Champaign,IL)','Luxury Community Features:\r\n\r\n2, 3, & 4 Luxury Apartment Homes \r\n24-Hour Emergency Service \r\nAsk about Our Preferred Employer Program \r\nExclusive Clubhouse \r\nGated Community \r\nGarages \r\nResort Style Swimming Pool & Sundeck \r\nBusiness Center \r\nConference Rooms \r\nWasher and Dryers Included \r\nHigh Speed Internet \r\nGet Fit Fitness Center \r\nIndoor Basketball Court \r\nSand Volleyball \r\nBilliards Room \r\nArcade Room \r\nBBQ and Picnic Area \r\nBike Racks \r\nBark Park \r\nCar Wash \r\nPet Friendly \r\nEasy Access to Public Transportation \r\nWalking Distance to Shopping And Dining \r\nFriendly Professional Management Team \r\nWheelchair Access \r\nSecurity Deposit: $150-$300, Hold Fee: $100, Application Fee: $35 per person, Pet Fee: $200, Pet Rent: $20 *Aggressive Breed Restrictions and 2 pet max. \r\n\r\nContact Drew at the Leasing Office to hear about our great specials!! \r\n\r\nThe Perfect Blend of Luxury and Convenience',NULL,NULL,NULL,'2013-12-11'),(56,' $889 / 2br - 1000ft² - 2 Bedroom Townhome 1.5 Bath (Hessel on the Park )','We are currently leasing for our lovely 2 bedroom 1.5 bath townhomes!!\r\n\r\nDont wait until the last minute lease NOW!\r\n\r\nCome check out our gorgeous location at Hessel on the Park! You\'ll love the quiet & convenient lifestyle that Hessel has to offer. \r\n\r\nHessel is a quiet community in a very residential location. You\'ll love the tree-lined streets guiding you to your new home. Located right on MTD bus lines( gold, yellow and brown) minutes from U of I, Assembly Hall, Wolfram Research, Amdocs, CUMTD. Various restaurants including Seaboat, Yellowfin, Kamakura, Jarling\'s Custard Cup and many more! \r\n\r\nIf you love to be outdoors, you\'ll definitely appreciate Hessel Park and the Boulware Nature Trail being connected to our community!\r\n\r\nWe have 24-hour maintenance, 24-hour fitness center, Sparkling swimming pool to enjoy during the summer, online rent payment options, laundry on site, central air and heat in all units and designated parking.\r\n\r\n\r\n\r\nWhat more could you ask for! $35.00 Application fee and deposits as low as $100.00\r\n\r\n\r\n- Kitchen connected to dining room \r\n- Tons of closet space \r\n- Washer and dryer in unit \r\n- Private patio area\r\n- Carports (optional) $25.00 a month \r\n- Central heat and air\r\n- Clean Carpet\r\n- And so much more!\r\n\r\n\r\n-24-hour maintenance\r\n-24-hour fitness center\r\n- Online rent payment options and smart phone app for rent payments \r\n-Beautiful pool \r\n-A quiet residential environment\r\n- Right next door to Boulware Nature Trail.....Across the street from Hessel Park! \r\n\r\nCall Jihan at 217-356-4012. \r\nTo learn more about our communities http://www.mckinley.com or apply at https://apply.mckinley.com\r\n',NULL,NULL,NULL,'2013-12-11'),(57,'$595 / 2br - 930ft² - Holiday Special going fast! Discount on the first ten 2-bdrms rented! (Champaign ','Town Center is located in the heart of the newest retail area in Champaign-Urbana. Town Center offers spacious two- and three-bedroom apartments ranging from 930 to 1,185 square feet. We are conveniently located near Market Place Mall, Wal-Mart, Menards, and multiple dining establishments. We are also on the local transit bus line. Our amenities include locked entry to each building, balconies or patios in every unit, washer-dryer connections, deluxe kitchen appliances, cable-ready wiring, 24-hour fitness center, swimming pool, clubhouse, playground, and a wonderful bike path. Garages are available and we also have laundry facilities on site. Call us today for an appointment.',NULL,NULL,NULL,'2013-12-11'),(58,NULL,'good!',NULL,57,NULL,'2013-12-11'),(59,NULL,'kkkkk\r\n',NULL,54,NULL,'2014-11-09');
/*!40000 ALTER TABLE `post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_category`
--

DROP TABLE IF EXISTS `post_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post_category` (
  `postID` int(11) NOT NULL,
  `categoryID` int(11) NOT NULL,
  PRIMARY KEY (`postID`,`categoryID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_category`
--

LOCK TABLES `post_category` WRITE;
/*!40000 ALTER TABLE `post_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `post_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `realEstate`
--

DROP TABLE IF EXISTS `realEstate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `realEstate` (
  `realEstateID` int(11) NOT NULL AUTO_INCREMENT,
  `startDate` date DEFAULT NULL,
  `endDate` date DEFAULT NULL,
  `pricePerMonth` int(11) DEFAULT NULL,
  `noOfBedrooms` int(11) DEFAULT NULL,
  `userID` int(11) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `createdDate` date DEFAULT NULL,
  `provider` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`realEstateID`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `realEstate`
--

LOCK TABLES `realEstate` WRITE;
/*!40000 ALTER TABLE `realEstate` DISABLE KEYS */;
INSERT INTO `realEstate` (`realEstateID`, `startDate`, `endDate`, `pricePerMonth`, `noOfBedrooms`, `userID`, `address`, `createdDate`, `provider`) VALUES (12,NULL,NULL,NULL,NULL,1,'2','2013-12-11',NULL),(13,NULL,NULL,NULL,NULL,1,'2','2013-12-11',NULL),(14,NULL,NULL,NULL,NULL,1,'2','2013-12-11',NULL),(15,NULL,NULL,NULL,NULL,1,'2','2013-12-11',NULL),(16,NULL,NULL,NULL,NULL,1,'2','2013-12-11',NULL),(17,NULL,NULL,NULL,NULL,1,'2','2013-12-11',NULL),(18,NULL,NULL,NULL,NULL,1,'2','2013-12-11',NULL),(19,NULL,NULL,NULL,NULL,1,'2','2013-12-11',NULL),(21,NULL,NULL,NULL,NULL,1,'3','2013-12-11',NULL),(22,NULL,NULL,NULL,NULL,1,'3','2013-12-11',NULL),(23,NULL,NULL,NULL,NULL,1,'3','2013-12-11',NULL),(24,NULL,NULL,NULL,NULL,1,'3','2013-12-11',NULL),(25,NULL,NULL,NULL,NULL,1,'3','2013-12-11',NULL),(26,NULL,NULL,NULL,NULL,1,'3','2013-12-11',NULL),(27,NULL,NULL,NULL,NULL,1,'4','2013-12-11',NULL),(28,NULL,NULL,NULL,NULL,1,'4','2013-12-11',NULL),(30,NULL,NULL,NULL,NULL,1,'4','2013-12-11',NULL),(32,NULL,NULL,NULL,NULL,1,'4','2013-12-11',NULL),(33,NULL,NULL,NULL,NULL,1,'8','2013-12-11',NULL),(34,NULL,NULL,NULL,NULL,1,'8','2013-12-11',NULL),(35,NULL,NULL,NULL,NULL,1,'8','2013-12-11',NULL),(36,NULL,NULL,NULL,NULL,1,'8','2013-12-11',NULL),(37,NULL,NULL,NULL,NULL,1,'29','2013-12-11',NULL),(38,NULL,NULL,NULL,NULL,1,'29','2013-12-11',NULL),(39,NULL,NULL,NULL,NULL,1,'29','2013-12-11',NULL),(41,NULL,NULL,NULL,NULL,1,'31','2013-12-11',NULL),(42,NULL,NULL,NULL,NULL,1,'31','2013-12-11',NULL),(43,NULL,NULL,NULL,NULL,1,'40','2013-12-11',NULL),(44,NULL,NULL,NULL,NULL,1,'40','2013-12-11',NULL),(45,NULL,NULL,NULL,NULL,1,'40','2013-12-11',NULL),(47,NULL,NULL,NULL,NULL,1,'46','2013-12-11',NULL),(48,NULL,NULL,NULL,NULL,1,'46','2013-12-11',NULL),(49,NULL,NULL,NULL,NULL,1,'3','2013-12-11',NULL),(50,'2013-12-08','2014-01-17',1000,3,1,'106 S. Gregory','2013-12-11','CPM'),(51,NULL,NULL,NULL,NULL,1,'50','2013-12-11',NULL),(52,NULL,NULL,NULL,NULL,1,'50','2013-12-11',NULL),(53,NULL,NULL,NULL,NULL,1,'50','2013-12-11',NULL),(54,'0000-00-00','0000-00-00',300,5,1,'Nantucket Cove  2001 North Moreland Blvd  Champaign IL 61822','2013-12-11','JSM'),(55,'2013-12-02','2013-12-26',600,5,1,'Nantucket Cove  2001 North Moreland Blvd  Champaign IL 61822','2013-12-11','CPM'),(56,'2013-12-03','2013-12-19',889,3,1,'Hessel on the Park','2013-12-11','Personal'),(57,'0000-00-00','0000-00-00',900,5,1,'2413 N. Neil Street , Champaign, IL, 61820','2013-12-11','CPM'),(58,NULL,NULL,NULL,NULL,1,'57','2013-12-11',NULL),(59,NULL,NULL,NULL,NULL,1,'54','2014-11-09',NULL);
/*!40000 ALTER TABLE `realEstate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `roleID` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`roleID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` (`roleID`, `description`) VALUES ('Account Administrator','Add, remove, and edit authors'),('Content Editor','Add, remove, and edit jokes'),('Site Administrator','Add, remove, and edit categories');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `userID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '0',
  `password` char(32) NOT NULL,
  `phoneNo` int(11) DEFAULT NULL,
  PRIMARY KEY (`userID`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`userID`, `name`, `email`, `active`, `password`, `phoneNo`) VALUES (6,'Alex','alex@gmail.com',0,'alex',2147483647),(7,NULL,'abc',0,'abc',NULL),(8,NULL,'chaoran',0,'chaoran',NULL),(9,NULL,'super@gmail.com',0,'super',NULL),(10,NULL,'wangmifen@gmail.com',0,'wang',NULL),(11,NULL,'cs411@gmail.com',0,'cs411',NULL),(12,NULL,'wang374@illinois.edu',0,'wang374',NULL),(13,NULL,'chen338@illinois.edu',0,'chen338@illinois.edu',NULL),(14,NULL,'a',0,'b',NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_role`
--

DROP TABLE IF EXISTS `user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_role` (
  `user_role_ID` int(11) NOT NULL,
  `roleID` varchar(255) NOT NULL,
  PRIMARY KEY (`user_role_ID`,`roleID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_role`
--

LOCK TABLES `user_role` WRITE;
/*!40000 ALTER TABLE `user_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'wonderland_wonderland'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-11-09 19:34:56
